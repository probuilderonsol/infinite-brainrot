import { readFileSync } from 'fs';
import { pool } from './index.js';

interface TrendSeed { name: string; description: string; aliases: string[]; examples: string[]; half_life_hours: number; category: string; }
interface FormatSeed { name: string; template: string; examples: string[]; }

let trendsSeed: TrendSeed[] = [];
let formatsSeed: FormatSeed[] = [];

try {
  trendsSeed = JSON.parse(readFileSync('./dist/data/trends_seed.json', 'utf-8'));
  formatsSeed = JSON.parse(readFileSync('./dist/data/formats_seed.json', 'utf-8'));
} catch {
  try {
    trendsSeed = JSON.parse(readFileSync('./src/data/trends_seed.json', 'utf-8'));
    formatsSeed = JSON.parse(readFileSync('./src/data/formats_seed.json', 'utf-8'));
  } catch (err) {
    console.error('Failed to load seed data:', err);
  }
}

export async function initializeTrends(): Promise<void> {
  console.log('📦 Initializing trends and formats...');
  
  for (const format of formatsSeed) {
    await pool.query(
      `INSERT INTO formats (name, template, examples) VALUES ($1, $2, $3) ON CONFLICT (name) DO UPDATE SET template = $2, examples = $3`,
      [format.name, format.template, format.examples]
    );
  }
  console.log(`  ✓ ${formatsSeed.length} formats loaded`);
  
  for (const trend of trendsSeed) {
    await pool.query(
      `INSERT INTO trends (name, description, aliases, example_formats, half_life_hours, lifecycle_stage) VALUES ($1, $2, $3, $4, $5, 'emerging') ON CONFLICT (name) DO UPDATE SET description = $2, aliases = $3, example_formats = $4, half_life_hours = $5`,
      [trend.name, trend.description, trend.aliases, trend.examples, trend.half_life_hours]
    );
  }
  console.log(`  ✓ ${trendsSeed.length} trends loaded`);
}

export async function selectSpotlightTrends(): Promise<void> {
  await pool.query(`UPDATE trends SET lifecycle_stage = 'peak' WHERE lifecycle_stage = 'spotlight' AND spotlight_until < NOW()`);
  
  const currentResult = await pool.query(`SELECT COUNT(*) as count FROM trends WHERE lifecycle_stage = 'spotlight'`);
  const currentCount = parseInt(currentResult.rows[0].count);
  if (currentCount >= 3) return;
  
  const needed = 3 - currentCount;
  const result = await pool.query(
    `SELECT id, name FROM trends WHERE lifecycle_stage IN ('emerging', 'peak') AND (usage_count_hour < 5 OR usage_count_hour IS NULL) ORDER BY RANDOM() LIMIT $1`,
    [needed]
  );
  
  for (const row of result.rows) {
    await pool.query(`UPDATE trends SET lifecycle_stage = 'spotlight', spotlight_until = NOW() + INTERVAL '1 hour' WHERE id = $1`, [row.id]);
    console.log(`  🔥 Spotlight: ${row.name}`);
  }
}

export async function getSpotlightTrends(): Promise<{ name: string; aliases: string[]; description: string }[]> {
  const result = await pool.query(`SELECT name, aliases, description FROM trends WHERE lifecycle_stage = 'spotlight'`);
  return result.rows;
}

export async function getActiveTrends(): Promise<{ name: string; aliases: string[]; description: string }[]> {
  const result = await pool.query(`SELECT name, aliases, description FROM trends WHERE lifecycle_stage IN ('spotlight', 'emerging', 'peak', 'ephemeral') ORDER BY weight DESC`);
  return result.rows;
}

export async function recordTrendUsage(trendName: string): Promise<void> {
  await pool.query(`UPDATE trends SET usage_count = usage_count + 1, usage_count_hour = usage_count_hour + 1, last_used_at = NOW() WHERE name = $1 OR $1 = ANY(aliases)`, [trendName]);
}

export async function getEphemeralReference(): Promise<string | null> {
  const result = await pool.query(`SELECT name, example_formats FROM trends WHERE lifecycle_stage = 'ephemeral' AND ephemeral_until > NOW() ORDER BY RANDOM() LIMIT 1`);
  if (result.rows.length > 0) return result.rows[0].example_formats[0] || result.rows[0].name;
  
  const newResult = await pool.query(
    `UPDATE trends SET lifecycle_stage = 'ephemeral', ephemeral_until = NOW() + INTERVAL '12 hours' WHERE id = (SELECT id FROM trends WHERE lifecycle_stage IN ('emerging', 'peak') ORDER BY RANDOM() LIMIT 1) RETURNING name, example_formats`
  );
  if (newResult.rows.length > 0) {
    console.log(`  🎭 New ephemeral: ${newResult.rows[0].name}`);
    return newResult.rows[0].example_formats[0] || newResult.rows[0].name;
  }
  return null;
}

export async function runTrendChurn(): Promise<void> {
  console.log('\n🔄 Running trend churn...');
  await pool.query(`UPDATE trends SET usage_count_hour = 0`);
  await pool.query(`UPDATE trends SET weight = weight * 0.9 WHERE weight > 0.1`);
  
  const overusedResult = await pool.query(
    `WITH total AS (SELECT COUNT(*) as count FROM thoughts WHERE created_at > NOW() - INTERVAL '6 hours'),
     trend_usage AS (SELECT unnest(trend_tags) as trend, COUNT(*) as count FROM thoughts WHERE created_at > NOW() - INTERVAL '6 hours' GROUP BY trend)
     SELECT trend, tu.count::float / NULLIF(t.count, 0) as pct FROM trend_usage tu, total t WHERE tu.count::float / NULLIF(t.count, 0) > 0.15`
  );
  
  for (const row of overusedResult.rows) {
    await pool.query(`UPDATE trends SET lifecycle_stage = 'stale', weight = weight * 0.5 WHERE name = $1`, [row.trend]);
    console.log(`  ⬇️  ${row.trend} demoted`);
  }
  
  await pool.query(`UPDATE trends SET lifecycle_stage = 'dead' WHERE lifecycle_stage = 'ephemeral' AND ephemeral_until < NOW()`);
  
  if (Math.random() < 0.1) {
    const resurrectResult = await pool.query(`UPDATE trends SET lifecycle_stage = 'emerging', weight = 0.8 WHERE id = (SELECT id FROM trends WHERE lifecycle_stage = 'dead' ORDER BY RANDOM() LIMIT 1) RETURNING name`);
    if (resurrectResult.rows.length > 0) console.log(`  🔮 Resurrected: ${resurrectResult.rows[0].name}`);
  }
  
  await pool.query(`UPDATE trends SET lifecycle_stage = 'dead' WHERE lifecycle_stage = 'stale' AND updated_at < NOW() - INTERVAL '24 hours'`);
  await pool.query(`UPDATE trends SET lifecycle_stage = 'peak' WHERE lifecycle_stage = 'emerging' AND usage_count > 10`);
  console.log('  ✅ Trend churn complete');
}
