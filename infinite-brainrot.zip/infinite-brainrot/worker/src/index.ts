import pg from 'pg';
import Redis from 'ioredis';
import { runGenerationCycle } from './generator.js';
import { runTrendChurn, initializeTrends, selectSpotlightTrends } from './trends.js';
import { runTwitterCycle, getTwitterStatus } from './twitter.js';

const { Pool } = pg;

const DATABASE_URL = process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/brainrot';
const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';

export const pool = new Pool({ connectionString: DATABASE_URL });
export const redis = new Redis(REDIS_URL);

const GENERATION_INTERVAL = 30 * 1000;
const TREND_CHURN_INTERVAL = 60 * 60 * 1000;
const TWITTER_CHECK_INTERVAL = 5 * 60 * 1000;

async function main() {
  console.log('🧠 Brainrot Worker starting...');
  
  await initializeTrends();
  await selectSpotlightTrends();
  
  const twitterStatus = getTwitterStatus();
  console.log(`🐦 Twitter: ${twitterStatus.enabled ? 'ENABLED' : 'DRY_RUN MODE'}`);
  
  console.log(`⏱️  Generation interval: ${GENERATION_INTERVAL / 1000}s`);
  setInterval(async () => {
    try {
      await runGenerationCycle();
    } catch (err) {
      console.error('Generation cycle error:', err);
    }
  }, GENERATION_INTERVAL);
  
  setTimeout(() => runGenerationCycle(), 5000);
  
  console.log(`⏱️  Trend churn interval: ${TREND_CHURN_INTERVAL / 1000 / 60}min`);
  setInterval(async () => {
    try {
      await runTrendChurn();
      await selectSpotlightTrends();
    } catch (err) {
      console.error('Trend churn error:', err);
    }
  }, TREND_CHURN_INTERVAL);
  
  console.log(`⏱️  Twitter check interval: ${TWITTER_CHECK_INTERVAL / 1000 / 60}min`);
  setInterval(async () => {
    try {
      await runTwitterCycle();
    } catch (err) {
      console.error('Twitter cycle error:', err);
    }
  }, TWITTER_CHECK_INTERVAL);
  
  setTimeout(() => runTwitterCycle(), 2 * 60 * 1000);
  
  console.log('✅ Worker running');
}

main().catch((err) => {
  console.error('Worker failed:', err);
  process.exit(1);
});
