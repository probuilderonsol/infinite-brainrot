import { TwitterApi } from 'twitter-api-v2';
import { pool, redis } from './index.js';

let twitterClient: TwitterApi | null = null;
let lastTweetTime = 0;
let nextTweetDelay = getRandomDelay();

function getRandomDelay(): number { return (20 + Math.random() * 40) * 60 * 1000; }

export function getTwitterStatus(): { enabled: boolean } {
  const hasKeys = !!(process.env.TWITTER_API_KEY && process.env.TWITTER_API_SECRET && process.env.TWITTER_ACCESS_TOKEN && process.env.TWITTER_ACCESS_SECRET);
  if (hasKeys && !twitterClient) {
    twitterClient = new TwitterApi({
      appKey: process.env.TWITTER_API_KEY!, appSecret: process.env.TWITTER_API_SECRET!,
      accessToken: process.env.TWITTER_ACCESS_TOKEN!, accessSecret: process.env.TWITTER_ACCESS_SECRET!,
    });
  }
  return { enabled: hasKeys };
}

async function getEligibleThoughts(limit = 10): Promise<any[]> {
  const result = await pool.query(
    `SELECT * FROM thoughts WHERE state = 'approved' AND risk_level = 'safe' AND score_composite >= 70 AND tweet_id IS NULL AND tweet_dry_run = FALSE ORDER BY score_composite DESC, created_at DESC LIMIT $1`,
    [limit]
  );
  return result.rows;
}

export async function runTwitterCycle(): Promise<void> {
  const now = Date.now();
  if (lastTweetTime > 0 && now - lastTweetTime < nextTweetDelay) {
    console.log(`🐦 Next tweet in ~${Math.ceil((nextTweetDelay - (now - lastTweetTime)) / 60000)} minutes`);
    return;
  }
  
  const eligible = await getEligibleThoughts(5);
  if (eligible.length === 0) { console.log('🐦 No eligible thoughts'); return; }
  
  const thought = eligible[Math.floor(Math.random() * Math.min(3, eligible.length))];
  const { enabled } = getTwitterStatus();
  
  if (enabled && twitterClient) {
    try {
      const result = await twitterClient.v2.tweet(thought.content);
      await pool.query(`UPDATE thoughts SET tweet_id = $1, tweeted_at = NOW(), state = 'tweeted' WHERE id = $2`, [result.data.id, thought.id]);
      await pool.query(`INSERT INTO tweet_log (thought_id, tweet_id, dry_run) VALUES ($1, $2, FALSE)`, [thought.id, result.data.id]);
      console.log(`🐦 TWEETED: "${thought.content.slice(0, 50)}..."`);
      lastTweetTime = now; nextTweetDelay = getRandomDelay();
    } catch (err) {
      console.error('🐦 Tweet failed:', err);
      await pool.query(`INSERT INTO tweet_log (thought_id, dry_run, error_message) VALUES ($1, FALSE, $2)`, [thought.id, err instanceof Error ? err.message : String(err)]);
    }
  } else {
    await pool.query(`UPDATE thoughts SET tweet_dry_run = TRUE WHERE id = $1`, [thought.id]);
    await pool.query(`INSERT INTO tweet_log (thought_id, dry_run) VALUES ($1, TRUE)`, [thought.id]);
    console.log(`🐦 DRY_RUN: "${thought.content.slice(0, 50)}..."`);
    lastTweetTime = now; nextTweetDelay = getRandomDelay();
  }
}
