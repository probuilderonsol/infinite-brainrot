import Anthropic from '@anthropic-ai/sdk';
import crypto from 'crypto';
import { z } from 'zod';
import { pool, redis } from './index.js';
import { getSpotlightTrends, getActiveTrends, recordTrendUsage, getEphemeralReference } from './trends.js';

const ScoresSchema = z.object({
  absurdity: z.number().min(0).max(100),
  brevity: z.number().min(0).max(100),
  trend_fit: z.number().min(0).max(100),
  eeriness: z.number().min(0).max(100),
  novelty: z.number().min(0).max(100),
});

const ThoughtSchema = z.object({
  content: z.string().min(5).max(300),
  format: z.string(),
  trends: z.array(z.string()),
  scores: ScoresSchema,
});

const ResponseSchema = z.object({
  thoughts: z.array(ThoughtSchema),
});

const BLOCKED_PATTERNS = [
  /\b(kill|murder|suicide|rape|n[i1]gg|f[a@]g|k[i1]ke|ch[i1]nk|sp[i1]c|ret[a@]rd)\b/i,
  /@[a-zA-Z0-9_]+/,
  /https?:\/\//i,
  /#[a-zA-Z0-9]+/,
];

const STALE_PHRASES = [
  'hits different', 'its giving', 'no cap', 'fr fr', 'lowkey highkey',
  'main character', 'its the ... for me', 'rent free', 'understood the assignment',
  'tell me youre', 'normalize', 'gaslight gatekeep', 'slay', 'bestie',
  'wholesome', 'self care', 'vibe check', 'big mood', 'and i oop',
];

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

interface Format { id: string; name: string; template: string; examples: string[]; }
interface Trend { name: string; aliases: string[]; description: string; }

async function getFormats(): Promise<Format[]> {
  const result = await pool.query(`SELECT * FROM formats WHERE is_active = true ORDER BY usage_count ASC`);
  return result.rows;
}

async function getRecentFormatDistribution(): Promise<Map<string, number>> {
  const result = await pool.query(
    `SELECT f.name, COUNT(*) as count FROM thoughts t JOIN formats f ON t.format_id = f.id WHERE t.created_at > NOW() - INTERVAL '2 hours' GROUP BY f.name`
  );
  const dist = new Map<string, number>();
  const total = result.rows.reduce((sum: number, r: any) => sum + parseInt(r.count), 0);
  for (const row of result.rows) {
    dist.set(row.name, parseInt(row.count) / Math.max(1, total));
  }
  return dist;
}

async function getRecentThoughts(limit = 50): Promise<string[]> {
  const cached = await redis.lrange('recent:thoughts', 0, limit - 1);
  if (cached.length > 0) return cached;
  const result = await pool.query(`SELECT content FROM thoughts ORDER BY created_at DESC LIMIT $1`, [limit]);
  return result.rows.map((r: any) => r.content);
}

function buildPrompt(spotlightTrends: Trend[], allTrends: Trend[], formats: Format[], formatDist: Map<string, number>, recentThoughts: string[], ephemeralRef: string | null, batchSize: number): string {
  const availableFormats = formats.filter(f => (formatDist.get(f.name) || 0) < 0.25);
  if (availableFormats.length < 3) availableFormats.push(...formats.slice(0, 3));
  
  const spotlightSection = spotlightTrends.map(t => `🔥 ${t.name} (aliases: ${t.aliases.join(', ')}): ${t.description}`).join('\n');
  const trendSection = allTrends.slice(0, 15).map(t => `- ${t.name} (aliases: ${t.aliases.join(', ')})`).join('\n');
  const formatSection = availableFormats.map(f => `- ${f.name}: "${f.template}" | examples: ${f.examples.slice(0, 2).join(' // ')}`).join('\n');
  const recentSection = recentThoughts.slice(0, 15).map(t => `- "${t}"`).join('\n');
  const staleSection = STALE_PHRASES.join(', ');
  const ephemeralSection = ephemeralRef ? `\n🎭 EPHEMERAL REFERENCE (use in ~20% of thoughts as if everyone knows it):\n"${ephemeralRef}"\nRefer to it obliquely, don't explain it.` : '';

  return `You are generating content for an infinite doomscroll feed of surreal, funny, chronically-online brainrot.

SPOTLIGHT TRENDS (30% of thoughts MUST reference these indirectly):
${spotlightSection}

OTHER ACTIVE TRENDS:
${trendSection}

AVAILABLE FORMATS (rotate between these):
${formatSection}

RECENT THOUGHTS (avoid similarity):
${recentSection}

STALE PHRASES TO NEVER USE:
${staleSection}
${ephemeralSection}

RULES:
1. Each thought: 10-200 chars, NEVER over 280
2. Lowercase preferred, punctuation optional
3. Funny first, absurd second, eerie third
4. NO real names, @handles, URLs, hashtags
5. NO politics, preaching, wholesome vibes
6. NO slurs, graphic violence, sexual content
7. NO "as an AI" or breaking fourth wall
8. Reference trends via aliases/vibes, not keyword stuffing
9. 30% must subtly reference a SPOTLIGHT trend
10. Each thought uses a DIFFERENT format

Generate exactly ${batchSize} thoughts. RESPOND WITH ONLY VALID JSON:
{
  "thoughts": [
    {
      "content": "the wifi router saw what you searched",
      "format": "object_lore",
      "trends": ["algorithm_sentience"],
      "scores": { "absurdity": 75, "brevity": 90, "trend_fit": 80, "eeriness": 60, "novelty": 85 }
    }
  ]
}`;
}

function hashContent(content: string): string {
  return crypto.createHash('sha256').update(content.toLowerCase().trim()).digest('hex').slice(0, 32);
}

async function checkDuplicate(content: string): Promise<boolean> {
  const hash = hashContent(content);
  const exactResult = await pool.query(`SELECT 1 FROM thoughts WHERE content_hash = $1 LIMIT 1`, [hash]);
  if (exactResult.rows.length > 0) return true;
  const similarResult = await pool.query(`SELECT 1 FROM thoughts WHERE created_at > NOW() - INTERVAL '24 hours' AND similarity(content, $1) > 0.6 LIMIT 1`, [content]);
  return similarResult.rows.length > 0;
}

function heuristicFilter(content: string): { pass: boolean; reason?: string } {
  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(content)) return { pass: false, reason: `Blocked pattern` };
  }
  if (content.length < 10) return { pass: false, reason: 'Too short' };
  if (content.length > 300) return { pass: false, reason: 'Too long' };
  return { pass: true };
}

export async function runGenerationCycle(): Promise<void> {
  const batchId = crypto.randomUUID();
  const startTime = Date.now();
  const batchSize = 5;
  
  console.log(`\n🧠 Generation batch ${batchId.slice(0, 8)}...`);
  
  if (!process.env.ANTHROPIC_API_KEY) {
    console.log('⚠️  No ANTHROPIC_API_KEY, skipping generation');
    return;
  }
  
  try {
    const [spotlightTrends, allTrends, formats, formatDist, recentThoughts] = await Promise.all([
      getSpotlightTrends(), getActiveTrends(), getFormats(), getRecentFormatDistribution(), getRecentThoughts(50),
    ]);
    
    const ephemeralRef = Math.random() < 0.2 ? await getEphemeralReference() : null;
    const prompt = buildPrompt(spotlightTrends, allTrends, formats, formatDist, recentThoughts, ephemeralRef, batchSize);
    
    let parsed: z.infer<typeof ResponseSchema> | null = null;
    let rawResponse = '';
    
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const response = await anthropic.messages.create({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 2000,
          messages: [{ role: 'user', content: prompt }],
        });
        
        rawResponse = response.content[0].type === 'text' ? response.content[0].text : '';
        let cleaned = rawResponse.trim();
        if (cleaned.startsWith('```json')) cleaned = cleaned.slice(7);
        if (cleaned.startsWith('```')) cleaned = cleaned.slice(3);
        if (cleaned.endsWith('```')) cleaned = cleaned.slice(0, -3);
        
        parsed = ResponseSchema.parse(JSON.parse(cleaned.trim()));
        break;
      } catch (err) {
        console.error(`  Attempt ${attempt} failed:`, err instanceof Error ? err.message : err);
        if (attempt === 3) throw err;
        await new Promise(r => setTimeout(r, 1000 * attempt));
      }
    }
    
    if (!parsed) return;
    
    let approved = 0, rejected = 0;
    
    for (const thought of parsed.thoughts) {
      const filter = heuristicFilter(thought.content);
      if (!filter.pass) { rejected++; continue; }
      
      const isDupe = await checkDuplicate(thought.content);
      if (isDupe) { rejected++; continue; }
      
      const formatResult = await pool.query(`SELECT id FROM formats WHERE name = $1`, [thought.format]);
      const formatId = formatResult.rows[0]?.id || null;
      
      const composite = Math.round(
        thought.scores.absurdity * 0.25 + thought.scores.brevity * 0.20 +
        thought.scores.trend_fit * 0.20 + thought.scores.eeriness * 0.15 + thought.scores.novelty * 0.20
      );
      
      const insertResult = await pool.query(
        `INSERT INTO thoughts (content, content_hash, format_id, trend_tags, score_absurdity, score_brevity, score_trend_fit, score_eeriness, score_novelty, score_composite, state, generation_batch)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'approved', $11) RETURNING id`,
        [thought.content, hashContent(thought.content), formatId, thought.trends, thought.scores.absurdity, thought.scores.brevity, thought.scores.trend_fit, thought.scores.eeriness, thought.scores.novelty, composite, batchId]
      );
      
      if (formatId) await pool.query(`UPDATE formats SET usage_count = usage_count + 1 WHERE id = $1`, [formatId]);
      for (const trend of thought.trends) await recordTrendUsage(trend);
      
      await redis.lpush('recent:thoughts', thought.content);
      await redis.ltrim('recent:thoughts', 0, 99);
      
      await redis.publish('thoughts:new', JSON.stringify({
        id: insertResult.rows[0].id, content: thought.content, trends: thought.trends,
        format: thought.format, corruption: 0, score: composite, timestamp: new Date().toISOString(), age: '0s',
      }));
      
      console.log(`  ✓ "${thought.content.slice(0, 50)}..." (score: ${composite})`);
      approved++;
    }
    
    await pool.query(
      `INSERT INTO generation_stats (batch_id, thoughts_generated, thoughts_approved, thoughts_rejected, latency_ms) VALUES ($1, $2, $3, $4, $5)`,
      [batchId, parsed.thoughts.length, approved, rejected, Date.now() - startTime]
    );
    
    console.log(`  ✅ Batch complete: ${approved}/${parsed.thoughts.length} approved (${Date.now() - startTime}ms)`);
  } catch (err) {
    console.error('  Generation error:', err);
    await pool.query(
      `INSERT INTO generation_stats (batch_id, thoughts_generated, error_message, latency_ms) VALUES ($1, 0, $2, $3)`,
      [batchId, err instanceof Error ? err.message : String(err), Date.now() - startTime]
    );
  }
}
