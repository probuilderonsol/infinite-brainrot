#!/bin/bash
set -e

echo "⏳ Waiting for PostgreSQL..."
until pg_isready -h postgres -U postgres; do
  sleep 1
done
echo "✅ PostgreSQL is ready"

echo "⏳ Waiting for Redis..."
until nc -z redis 6379; do
  sleep 1
done
echo "✅ Redis is ready"

echo "📦 Running migrations..."
psql "$DATABASE_URL" -f /app/migrations/001_init.sql 2>/dev/null || echo "Migrations already applied"

echo "🚀 Starting worker..."
exec node dist/index.js
