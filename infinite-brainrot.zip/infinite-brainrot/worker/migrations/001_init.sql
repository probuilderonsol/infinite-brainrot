CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

CREATE TABLE IF NOT EXISTS formats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL UNIQUE,
    template TEXT NOT NULL,
    examples TEXT[] DEFAULT '{}',
    usage_count INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS trends (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    aliases TEXT[] DEFAULT '{}',
    example_formats TEXT[] DEFAULT '{}',
    lifecycle_stage TEXT DEFAULT 'emerging'
        CHECK (lifecycle_stage IN ('spotlight', 'emerging', 'peak', 'stale', 'dead', 'ephemeral')),
    weight REAL DEFAULT 1.0,
    half_life_hours REAL DEFAULT 24,
    usage_count INTEGER DEFAULT 0,
    usage_count_hour INTEGER DEFAULT 0,
    last_used_at TIMESTAMPTZ,
    spotlight_until TIMESTAMPTZ,
    ephemeral_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS thoughts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    content TEXT NOT NULL,
    content_hash TEXT,
    format_id UUID REFERENCES formats(id),
    trend_tags TEXT[] DEFAULT '{}',
    score_absurdity SMALLINT CHECK (score_absurdity BETWEEN 0 AND 100),
    score_brevity SMALLINT CHECK (score_brevity BETWEEN 0 AND 100),
    score_trend_fit SMALLINT CHECK (score_trend_fit BETWEEN 0 AND 100),
    score_eeriness SMALLINT CHECK (score_eeriness BETWEEN 0 AND 100),
    score_novelty SMALLINT CHECK (score_novelty BETWEEN 0 AND 100),
    score_composite SMALLINT,
    state TEXT NOT NULL DEFAULT 'pending'
        CHECK (state IN ('pending', 'approved', 'tweeted', 'rejected', 'quarantined')),
    risk_level TEXT DEFAULT 'safe'
        CHECK (risk_level IN ('safe', 'edgy_ok', 'review', 'blocked')),
    moderation_note TEXT,
    corruption REAL DEFAULT 0 CHECK (corruption BETWEEN 0 AND 1),
    tweet_id TEXT,
    tweet_dry_run BOOLEAN DEFAULT FALSE,
    tweeted_at TIMESTAMPTZ,
    generation_batch UUID,
    model_version TEXT DEFAULT 'claude-sonnet-4-20250514',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_content_hash UNIQUE (content_hash)
);

CREATE INDEX IF NOT EXISTS idx_thoughts_state ON thoughts(state);
CREATE INDEX IF NOT EXISTS idx_thoughts_score ON thoughts(score_composite DESC);
CREATE INDEX IF NOT EXISTS idx_thoughts_created ON thoughts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_thoughts_trends ON thoughts USING GIN(trend_tags);
CREATE INDEX IF NOT EXISTS idx_thoughts_content_trgm ON thoughts USING GIN(content gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_trends_stage ON trends(lifecycle_stage);

CREATE TABLE IF NOT EXISTS generation_stats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    batch_id UUID NOT NULL,
    thoughts_generated INTEGER DEFAULT 0,
    thoughts_approved INTEGER DEFAULT 0,
    thoughts_rejected INTEGER DEFAULT 0,
    latency_ms INTEGER,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tweet_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    thought_id UUID REFERENCES thoughts(id),
    tweet_id TEXT,
    dry_run BOOLEAN DEFAULT FALSE,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
