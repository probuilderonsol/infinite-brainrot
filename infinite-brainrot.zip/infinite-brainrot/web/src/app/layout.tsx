import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = { title: 'Infinite Brainrot Backrooms', description: 'Endless doomscroll into the void' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body className="min-h-screen bg-void">{children}</body></html>;
}
