'use client';
import { useState, useEffect, useRef, useCallback } from 'react';

interface Thought { id: string; content: string; trends: string[]; format: string; corruption: number; score: number; timestamp: string; age: string; }

const API_URL = typeof window !== 'undefined' ? (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001') : 'http://api:3001';
const WS_URL = typeof window !== 'undefined' ? (process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:3001') : 'ws://api:3001';

function formatAge(timestamp: string): string {
  const seconds = Math.floor((Date.now() - new Date(timestamp).getTime()) / 1000);
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
  return `${Math.floor(seconds / 86400)}d`;
}

function ThoughtCard({ thought, isNew }: { thought: Thought; isNew: boolean }) {
  return (
    <article className={`px-4 py-4 border-b border-white/5 hover:bg-white/5 transition-all ${isNew ? 'thought-enter bg-glow/5' : ''}`}>
      <p className="text-white/90 text-sm leading-relaxed mb-2">{thought.content}</p>
      <div className="flex items-center justify-between text-xs text-white/30">
        <div className="flex items-center gap-2">
          {thought.trends?.slice(0, 2).map((tag) => <span key={tag} className="px-1.5 py-0.5 bg-white/5 rounded text-white/40">{tag}</span>)}
          <span className="text-white/20">{thought.format}</span>
        </div>
        <div className="flex items-center gap-2">
          {thought.score >= 80 && <span className="text-yellow-500">★</span>}
          <span>{formatAge(thought.timestamp)}</span>
        </div>
      </div>
    </article>
  );
}

export default function Home() {
  const [thoughts, setThoughts] = useState<Thought[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [cursor, setCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [liveMode, setLiveMode] = useState(true);
  const [newIds, setNewIds] = useState<Set<string>>(new Set());
  const [connected, setConnected] = useState(false);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  const fetchThoughts = useCallback(async (cursorId?: string) => {
    try {
      const url = new URL(`${API_URL}/v1/feed`);
      if (cursorId) url.searchParams.set('cursor', cursorId);
      url.searchParams.set('limit', '20');
      const res = await fetch(url.toString());
      if (!res.ok) throw new Error('Failed');
      return await res.json();
    } catch { return { thoughts: [], nextCursor: null, hasMore: false }; }
  }, []);

  useEffect(() => {
    fetchThoughts().then((data) => { setThoughts(data.thoughts || []); setCursor(data.nextCursor); setHasMore(data.hasMore); setLoading(false); });
  }, [fetchThoughts]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore || !cursor) return;
    setLoadingMore(true);
    const data = await fetchThoughts(cursor);
    setThoughts(prev => [...prev, ...(data.thoughts || [])]);
    setCursor(data.nextCursor);
    setHasMore(data.hasMore);
    setLoadingMore(false);
  }, [cursor, hasMore, loadingMore, fetchThoughts]);

  useEffect(() => {
    if (observerRef.current) observerRef.current.disconnect();
    observerRef.current = new IntersectionObserver((entries) => { if (entries[0].isIntersecting && hasMore && !loadingMore) loadMore(); }, { threshold: 0.1 });
    if (loadMoreRef.current) observerRef.current.observe(loadMoreRef.current);
    return () => observerRef.current?.disconnect();
  }, [hasMore, loadingMore, loadMore]);

  useEffect(() => {
    if (!liveMode) { wsRef.current?.close(); setConnected(false); return; }
    const connect = () => {
      try {
        const ws = new WebSocket(`${WS_URL}/v1/feed/live`);
        ws.onopen = () => { setConnected(true); };
        ws.onmessage = (event) => {
          try {
            const message = JSON.parse(event.data);
            if (message.type === 'new_thought' && message.data) {
              setThoughts(prev => [message.data, ...prev]);
              setNewIds(prev => new Set([...prev, message.data.id]));
              setTimeout(() => setNewIds(prev => { const next = new Set(prev); next.delete(message.data.id); return next; }), 3000);
            }
          } catch {}
        };
        ws.onclose = () => { setConnected(false); setTimeout(connect, 3000); };
        ws.onerror = () => ws.close();
        wsRef.current = ws;
      } catch { setTimeout(connect, 3000); }
    };
    connect();
    return () => wsRef.current?.close();
  }, [liveMode]);

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="text-white/40 animate-pulse">loading the void...</div></div>;

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-50 bg-void/90 backdrop-blur border-b border-white/10">
        <div className="max-w-xl mx-auto px-4 py-3 flex items-center justify-between">
          <div><h1 className="text-lg font-bold text-white">INFINITE BRAINROT</h1><p className="text-[10px] text-white/30">backrooms edition</p></div>
          <div className="flex items-center gap-3">
            <button onClick={() => setLiveMode(!liveMode)} className={`px-2 py-1 rounded text-xs transition-colors ${liveMode ? 'bg-glow/20 text-glow border border-glow/30' : 'bg-white/10 text-white/40 border border-white/10'}`}>{liveMode ? '◉ LIVE' : '○ PAUSED'}</button>
            <div className={`w-2 h-2 rounded-full ${connected ? 'bg-glow animate-glow-pulse' : 'bg-red-500'}`} />
          </div>
        </div>
      </header>
      <div className="max-w-xl mx-auto">
        {thoughts.length === 0 ? <div className="p-8 text-center text-white/30">the void is empty...</div> : thoughts.map((t) => <ThoughtCard key={t.id} thought={t} isNew={newIds.has(t.id)} />)}
        <div ref={loadMoreRef} className="p-8 text-center">{loadingMore ? <span className="text-white/40 animate-pulse">descending deeper...</span> : hasMore ? <span className="text-white/20">∿∿∿</span> : <span className="text-white/20">bottom reached</span>}</div>
      </div>
      <div className="fixed bottom-4 right-4"><a href="/admin" className="text-xs text-white/20 hover:text-white/40">admin →</a></div>
    </main>
  );
}
