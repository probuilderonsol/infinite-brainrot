'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';

interface Status { status: string; stats: { thoughts_last_10_min: number; tweets_24h: number; dry_run_candidates_24h: number; }; active_trends: Array<{ name: string; lifecycle_stage: string; weight: number; usage_count_hour: number; }>; format_distribution: Array<{ name: string; count: string; }>; recent_thoughts: Array<{ content: string; score: number; age: string; }>; timestamp: string; }

const API_URL = typeof window !== 'undefined' ? (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001') : 'http://api:3001';

export default function AdminPage() {
  const [status, setStatus] = useState<Status | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await fetch(`${API_URL}/v1/status`);
        if (res.ok) setStatus(await res.json());
      } catch {}
      setLoading(false);
    };
    fetchStatus();
    const interval = setInterval(fetchStatus, 10000);
    return () => clearInterval(interval);
  }, []);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-void"><div className="text-white/40 animate-pulse">loading...</div></div>;

  return (
    <main className="min-h-screen bg-void p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div><h1 className="text-2xl font-bold text-white">ADMIN STATUS</h1><p className="text-xs text-white/40">Updated: {status?.timestamp ? new Date(status.timestamp).toLocaleTimeString() : 'N/A'}</p></div>
          <Link href="/" className="text-sm text-glow hover:underline">← Back</Link>
        </div>
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-white/5 rounded-lg p-4 border border-white/10"><div className="text-3xl font-bold text-glow">{status?.stats.thoughts_last_10_min || 0}</div><div className="text-xs text-white/40">Thoughts (10 min)</div></div>
          <div className="bg-white/5 rounded-lg p-4 border border-white/10"><div className="text-3xl font-bold text-blue-400">{status?.stats.tweets_24h || 0}</div><div className="text-xs text-white/40">Tweets (24h)</div></div>
          <div className="bg-white/5 rounded-lg p-4 border border-white/10"><div className="text-3xl font-bold text-yellow-400">{status?.stats.dry_run_candidates_24h || 0}</div><div className="text-xs text-white/40">Dry Run Candidates</div></div>
        </div>
        <div className="grid grid-cols-2 gap-6">
          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h2 className="text-sm font-bold text-white mb-4">ACTIVE TRENDS</h2>
            <div className="space-y-2">{status?.active_trends.map((t) => <div key={t.name} className="flex items-center justify-between text-sm"><div className="flex items-center gap-2"><span className={`w-2 h-2 rounded-full ${t.lifecycle_stage === 'spotlight' ? 'bg-orange-400' : t.lifecycle_stage === 'peak' ? 'bg-green-400' : 'bg-blue-400'}`} /><span className="text-white/80">{t.name}</span></div><span className="text-xs text-white/40">{t.lifecycle_stage}</span></div>)}</div>
          </div>
          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h2 className="text-sm font-bold text-white mb-4">FORMAT DISTRIBUTION</h2>
            <div className="space-y-2">{status?.format_distribution.map((f) => <div key={f.name} className="flex items-center justify-between text-sm"><span className="text-white/80">{f.name}</span><span className="text-white/40">{f.count}</span></div>)}</div>
          </div>
        </div>
        <div className="mt-6 bg-white/5 rounded-lg p-4 border border-white/10">
          <h2 className="text-sm font-bold text-white mb-4">RECENT THOUGHTS</h2>
          <div className="space-y-3">{status?.recent_thoughts.map((t, i) => <div key={i} className="flex items-start justify-between gap-4 text-sm"><span className="text-white/80 flex-1">{t.content}</span><div className="flex items-center gap-2 text-white/40 shrink-0"><span className={t.score >= 70 ? 'text-glow' : ''}>{t.score}</span><span>{t.age}</span></div></div>)}</div>
        </div>
      </div>
    </main>
  );
}
