/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: { void: '#0a0a0a', glow: '#00ff88' },
      animation: { 'glow-pulse': 'glow-pulse 2s ease-in-out infinite', 'slide-up': 'slide-up 0.3s ease-out' },
      keyframes: {
        'glow-pulse': { '0%, 100%': { opacity: '1' }, '50%': { opacity: '0.5' } },
        'slide-up': { '0%': { transform: 'translateY(10px)', opacity: '0' }, '100%': { transform: 'translateY(0)', opacity: '1' } },
      },
    },
  },
  plugins: [],
};
