import Fastify from 'fastify';
import cors from '@fastify/cors';
import websocket from '@fastify/websocket';
import pg from 'pg';
import Redis from 'ioredis';

const { Pool } = pg;

const DATABASE_URL = process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/brainrot';
const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';
const PORT = parseInt(process.env.PORT || '3001', 10);

const pool = new Pool({ connectionString: DATABASE_URL });
const redis = new Redis(REDIS_URL);
const subscriber = new Redis(REDIS_URL);

interface Thought {
  id: string;
  content: string;
  trend_tags: string[];
  format_name: string;
  corruption: number;
  score_composite: number;
  created_at: Date;
}

interface FeedItem {
  id: string;
  content: string;
  trends: string[];
  format: string;
  corruption: number;
  score: number;
  timestamp: string;
  age: string;
}

function formatAge(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
  return `${Math.floor(seconds / 86400)}d`;
}

function toFeedItem(t: Thought): FeedItem {
  return {
    id: t.id,
    content: t.content,
    trends: t.trend_tags || [],
    format: t.format_name || 'unknown',
    corruption: t.corruption || 0,
    score: t.score_composite || 0,
    timestamp: t.created_at.toISOString(),
    age: formatAge(new Date(t.created_at)),
  };
}

const fastify = Fastify({ logger: true });

async function start() {
  await fastify.register(cors, { origin: true });
  await fastify.register(websocket);

  const clients = new Set<WebSocket>();

  subscriber.subscribe('thoughts:new');
  subscriber.on('message', (channel, message) => {
    if (channel === 'thoughts:new') {
      for (const client of clients) {
        if (client.readyState === 1) {
          client.send(JSON.stringify({ type: 'new_thought', data: JSON.parse(message) }));
        }
      }
    }
  });

  setInterval(() => {
    const msg = JSON.stringify({ type: 'heartbeat', timestamp: Date.now() });
    for (const client of clients) {
      if (client.readyState === 1) client.send(msg);
    }
  }, 30000);

  fastify.get('/v1/feed/live', { websocket: true }, (socket) => {
    clients.add(socket);
    socket.on('close', () => clients.delete(socket));
    socket.on('error', () => clients.delete(socket));
  });

  fastify.get('/v1/feed', async (request, reply) => {
    const { cursor, limit = 20 } = request.query as { cursor?: string; limit?: number };
    const limitNum = Math.min(50, Math.max(1, Number(limit)));

    let query = `
      SELECT t.*, f.name as format_name
      FROM thoughts t
      LEFT JOIN formats f ON t.format_id = f.id
      WHERE t.state IN ('approved', 'tweeted')
    `;
    const params: unknown[] = [];

    if (cursor) {
      query += ` AND t.created_at < (SELECT created_at FROM thoughts WHERE id = $1)`;
      params.push(cursor);
    }

    query += ` ORDER BY t.created_at DESC LIMIT $${params.length + 1}`;
    params.push(limitNum + 1);

    const result = await pool.query(query, params);
    const thoughts = result.rows as Thought[];
    const hasMore = thoughts.length > limitNum;
    const items = hasMore ? thoughts.slice(0, -1) : thoughts;

    return {
      thoughts: items.map(toFeedItem),
      nextCursor: hasMore && items.length > 0 ? items[items.length - 1].id : null,
      hasMore,
    };
  });

  fastify.get('/v1/thought/:id', async (request, reply) => {
    const { id } = request.params as { id: string };
    const result = await pool.query(
      `SELECT t.*, f.name as format_name FROM thoughts t LEFT JOIN formats f ON t.format_id = f.id WHERE t.id = $1`,
      [id]
    );
    if (result.rows.length === 0) {
      return reply.status(404).send({ error: 'Not found' });
    }
    return toFeedItem(result.rows[0]);
  });

  fastify.get('/v1/status', async () => {
    const thoughtsResult = await pool.query(
      `SELECT COUNT(*) as count FROM thoughts WHERE created_at > NOW() - INTERVAL '10 minutes'`
    );

    const tweetsResult = await pool.query(
      `SELECT 
        COUNT(*) FILTER (WHERE tweet_id IS NOT NULL) as tweeted,
        COUNT(*) FILTER (WHERE tweet_id IS NULL AND state = 'approved' AND score_composite >= 70) as dry_run_candidates
       FROM thoughts WHERE created_at > NOW() - INTERVAL '24 hours'`
    );

    const trendsResult = await pool.query(
      `SELECT name, lifecycle_stage, weight, usage_count_hour 
       FROM trends 
       WHERE lifecycle_stage IN ('spotlight', 'peak', 'emerging')
       ORDER BY weight DESC LIMIT 10`
    );

    const recentResult = await pool.query(
      `SELECT content, score_composite, created_at FROM thoughts 
       WHERE state IN ('approved', 'tweeted')
       ORDER BY created_at DESC LIMIT 5`
    );

    const formatResult = await pool.query(
      `SELECT f.name, COUNT(*) as count
       FROM thoughts t
       JOIN formats f ON t.format_id = f.id
       WHERE t.created_at > NOW() - INTERVAL '1 hour'
       GROUP BY f.name
       ORDER BY count DESC`
    );

    return {
      status: 'healthy',
      stats: {
        thoughts_last_10_min: parseInt(thoughtsResult.rows[0].count),
        tweets_24h: parseInt(tweetsResult.rows[0].tweeted),
        dry_run_candidates_24h: parseInt(tweetsResult.rows[0].dry_run_candidates),
      },
      active_trends: trendsResult.rows,
      format_distribution: formatResult.rows,
      recent_thoughts: recentResult.rows.map((r: any) => ({
        content: r.content,
        score: r.score_composite,
        age: formatAge(new Date(r.created_at)),
      })),
      timestamp: new Date().toISOString(),
    };
  });

  await fastify.listen({ port: PORT, host: '0.0.0.0' });
  console.log(`🚀 API running on port ${PORT}`);
}

start().catch((err) => {
  console.error('Failed to start API:', err);
  process.exit(1);
});
